﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace Library._2_Common
{
    public class Tools
    {
        /// <summary>
        /// Projenin Adını bana geri döndürecek metodumu tanımladım ...
        /// </summary>
        public static string ProjectName
        {
            get
            {
                return "Plato Dvd Dukkani v.3.1";
            }
        }

        // ---------------------------------------------

        public static string GetConnectionString(ConnectionType iletisimTalebim)
        {
            switch (iletisimTalebim)
            {
                case ConnectionType.SQL:
                    return "Server=.; Database=FilmDukkaniDB; UID=sa;PWD=1234";
                case ConnectionType.Windows:
                    return "Server=.; Database=FilmDukkaniDB; Integrated Security = true"; // veya yes
                default:
                    return "";
            }
        }

        public enum ConnectionType
        {
            SQL, // Sql Authentication -> Şifreli Bağlantı
            Windows // Windows Authentication -> Şifresiz Bağlantı seçmesini enum şle verdiriyoruz ...
        }

        public static SqlConnection GetConnection(string ConnectionString)
        {
            SqlConnection cnn = new SqlConnection(ConnectionString);
            return cnn;

            //veya 
            // return new SqlConnection(ConnectionString);
        }
        /// <summary>
        /// Insert / Update / Delete işlemlerinde -> ExecuteNonQuery kullanıyoruz bu yapılar -> ExecuteQuery Tabanlıdır
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        public static int ExecuteQuery(SqlCommand cmd)
        {
            int result = -1;
            try
            {
                if (cmd.Connection.State == ConnectionState.Closed)
                {
                    cmd.Connection.Open();
                }
                result = cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                result = -1;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return result;
        }

        public static object ExecuteScalar(SqlCommand cmd)// Tek tablo tek sutun
        {
            object result = -1;
            try
            {
                if (cmd.Connection.State == ConnectionState.Closed)
                {
                    cmd.Connection.Open();
                }
                result = cmd.ExecuteScalar
();
            }
            catch (Exception)
            {
                result = null;
            }
            finally
            {
                cmd.Connection.Close();
            }
            return result;
        }

        public static DataTable ExecuteFill(SqlDataAdapter adapter)
        {
            DataTable dt = new DataTable();
            try
            {
                if (adapter != null)
                {
                    adapter.Fill(dt);
                }
            }
            catch (Exception)
            {

                dt = null;
            }
            return dt;
        }
    }
}
