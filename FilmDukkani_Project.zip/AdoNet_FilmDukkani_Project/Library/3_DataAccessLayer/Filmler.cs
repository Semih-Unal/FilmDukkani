﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//----------------
using Library._1_Model;
using Library._2_Common;
//----------------------
using System.Data.SqlClient;
using System.Data;

namespace Library._3_DataAccessLayer
{
    public class Filmler
    {
        public static SqlConnection cnn = new SqlConnection(Tools.GetConnectionString(Tools.ConnectionType.SQL));

        // List (Select) Metodumuz :

        public static List<Films> List()
        {
            List<Films> filmler = new List<Films>();

            SqlCommand cmd = new SqlCommand("Select * From Filmler",cnn);

            try
            {
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                SqlDataReader reader = cmd.ExecuteReader() ;

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Films f = new Films();
                        f.FilmId = Convert.ToInt32(reader["FilmId"]);
                        f.FilmAdi = reader["FilmAdi"].ToString();
                        f.Sene = Convert.ToInt32(reader["Sene"]);
                        f.Aciklama = reader["Aciklama"].ToString();
                        f.BuyukResim = reader["BuyukResim"].ToString();
                        f.KucukResim = reader["KucukResim"].ToString();
                        f.IMDBPuan = Convert.ToDecimal(reader["IMDBPuan"]);
                        f.YapimSirketi = reader["YapimSirketi"].ToString();
                        f.Sure = Convert.ToInt32(reader["Sure"]);

                        filmler.Add(f);
                    }
                }
            }
            catch (Exception)
            {
                filmler = null;
            }
            finally
            {
                cmd.Connection.Close();
                //cnn.Close();
            }
            return filmler;
        }

        // Ekleme (Insert) Metodumuz : 
        public static int AddItem(Films item)
        {
            SqlCommand cmd = new SqlCommand("Insert Into Filmler (FilmAdi,Sene,Aciklama,BuyukResim,KucukResim,IMDBPuan,YapimSirketi,Sure) values (@FilmAdi,@Sene,@Aciklama,@BuyukResim,@KucukResim,@IMDBPuan,@YapimSirketi,@Sure)", cnn);

            cmd.Parameters.AddWithValue("@FilmAdi", item.FilmAdi);
            cmd.Parameters.AddWithValue("@Sene", item.Sene);
            cmd.Parameters.AddWithValue("@Aciklama", item.Aciklama);
            cmd.Parameters.AddWithValue("@BuyukResim", item.BuyukResim);
            cmd.Parameters.AddWithValue("@KucukResim", item.KucukResim);
            cmd.Parameters.AddWithValue("@IMDBPuan", item.IMDBPuan);
            cmd.Parameters.AddWithValue("@YapimSirketi", item.YapimSirketi);
            cmd.Parameters.AddWithValue("@Sure", item.Sure);

            int result = Tools.ExecuteQuery(cmd);
            return result;

        }
        // Güncelleme (Update) Metodumuz :
        public static int UpdateItem(Films item)
        {
            SqlCommand cmd = new SqlCommand("Update Filmler Set FilmAdi = @FilmAdi,Sene = @Sene,Aciklama = @Aciklama,BuyukResim = @BuyukResim,KucukResim = @KucukResim,IMDBPuan = @IMDBPuan,YapimSirketi = @YapimSirketi,Sure = @Sure WHERE FilmId = @id", cnn);

            cmd.Parameters.AddWithValue("@id", item.FilmId);
            cmd.Parameters.AddWithValue("@FilmAdi", item.FilmAdi);
            cmd.Parameters.AddWithValue("@Sene", item.Sene);
            cmd.Parameters.AddWithValue("@Aciklama", item.Aciklama);
            cmd.Parameters.AddWithValue("@BuyukResim", item.BuyukResim);
            cmd.Parameters.AddWithValue("@KucukResim", item.KucukResim);
            cmd.Parameters.AddWithValue("@IMDBPuan", item.IMDBPuan);
            cmd.Parameters.AddWithValue("@YapimSirketi", item.YapimSirketi);
            cmd.Parameters.AddWithValue("@Sure", item.Sure);

            int result = Tools.ExecuteQuery(cmd);
            return result;
        }
        // Silme (Delete) Metodumuz : 
        public static int DeleteItem(object itemId)
        {
            SqlCommand cmd = new SqlCommand("DELETE FROM Filmler WHERE FilmId = @id", cnn);

            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(itemId));

            int result = Tools.ExecuteQuery(cmd);
            return result;
        }
    }
}
