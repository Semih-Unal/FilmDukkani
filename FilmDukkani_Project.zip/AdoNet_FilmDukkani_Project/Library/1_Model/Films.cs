﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library._1_Model
{
    public class Films
    {
        public int FilmId { get; set; }
        public string FilmAdi { get; set; }
        public int Sene { get; set; }
        public string Aciklama { get; set; }
        public string BuyukResim { get; set; }
        public string KucukResim { get; set; }
        public decimal IMDBPuan { get; set; }
        public string YapimSirketi { get; set; }
        public int Sure { get; set; }
        
    }
}
