﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO; // Path için ekledik
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Library._1_Model;
using Library._2_Common;
using Library._3_DataAccessLayer;
using System.Data.SqlClient;
namespace GUI
{
    public partial class frmBilgiler : Form
    {
        public frmBilgiler()
        {
            InitializeComponent();
        }
        
        private void frmBilgiler_Load(object sender, EventArgs e)
        {
            for (int i = 1950; i <= DateTime.Now.Year; i++)
            {
                cbYil.Items.Add(i.ToString());
            }

            if (btnFilmEkle.Visible == true)
                btnFilmEkle.Location = new Point(192, 408);
            if (btnFilmGuncelle.Visible == true)
                btnFilmGuncelle.Location = new Point(192, 408);
        }

        private void btnBuyukResim_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png|All Files(*.*)|*.*";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                txtBuyukResim.Text = ofd.FileName;
            }
        }

        private void btnKucukResim_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png|All Files(*.*)|*.*";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                txtKucukResim.Text = ofd.FileName;
            }
        }

        private void btnFilmEkle_Click(object sender, EventArgs e)
        {
            try
            {
                Films film = new Films();

                film.FilmAdi = txtFilmAdi.Text;
                film.Sene = Convert.ToInt32(cbYil.SelectedItem);
                film.IMDBPuan = nUdImdb.Value;
                film.Sure = Convert.ToInt32(nUdSure.Value);
                film.Aciklama = txtAciklama.Text;
                film.YapimSirketi = txtYapimSirketi.Text;
                //------------------------------------
                //film.BuyukResim için;
                string buyukResim = @"..\..\Images\Large\large_" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(txtBuyukResim.Text);

                Image imgBuyuk = Image.FromFile(txtBuyukResim.Text);

                imgBuyuk.Save(buyukResim);

                film.BuyukResim = buyukResim;
                //------------------------------------
                //film.KucukResim için;
                string kucukukResim = @"..\..\Images\Small\small_" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(txtKucukResim.Text);

                Image imgKucuk = Image.FromFile(txtKucukResim.Text);

                imgKucuk.Save(kucukukResim);

                film.KucukResim = kucukukResim;
                //-----------------------------------
                int result = Filmler.AddItem(film);

                if (result != 0)
                {
                    MessageBox.Show("Ekleme İşlemi Başarılı Şekilde Gerçekleşmiştir.");
                }
                Temizle();
                this.Hide();
                Form1 frm = new Form1();
                frm.Show();
                frm.toolStripStatusLabelVeriler.Text = "1 Kayıt Eklenmiştir.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("İşlem Sırasında Bir Hata Oluştu!"+ex.Message);
            }
        }

        private void btnFilmGuncelle_Click(object sender, EventArgs e)
        {
            try
            {
                Form1 frm = new Form1();
                //-------------------------
                Films film = new Films();

                film.FilmId = Convert.ToInt32(txtFilmId.Text);
                film.FilmAdi = txtFilmAdi.Text;
                film.Sene = Convert.ToInt32(cbYil.SelectedItem);
                film.IMDBPuan = nUdImdb.Value;
                film.Sure = Convert.ToInt32(nUdSure.Value);
                film.Aciklama = txtAciklama.Text;
                film.YapimSirketi = txtYapimSirketi.Text;
                //------------------------------------
                //film.BuyukResim için;
                string buyukResim = @"..\..\Images\Large\large_" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(txtBuyukResim.Text);

                Image imgBuyuk = Image.FromFile(txtBuyukResim.Text);

                imgBuyuk.Save(buyukResim);

                film.BuyukResim = buyukResim;
                //------------------------------------
                //film.KucukResim için;
                string kucukukResim = @"..\..\Images\Small\small_" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(txtKucukResim.Text);

                Image imgKucuk = Image.FromFile(txtKucukResim.Text);

                imgKucuk.Save(kucukukResim);

                film.KucukResim = kucukukResim;
                //-----------------------------------
                
                int result = Filmler.UpdateItem(film);

                if (result != 0)
                {
                    MessageBox.Show("Güncelleme İşlemi Başarılı Şekilde Gerçekleşmiştir.");
                }
                Temizle();
                this.Hide();
                frm.Show();
                frm.toolStripStatusLabelVeriler.Text = "1 Veri Güncellenmiştir.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("İşlem Sırasında Bir Hata Oluştu!" + ex.Message);
            }
        }


        private void Temizle()
        {
            txtFilmAdi.Clear();
            cbYil.Text = "- Yıl Seçiniz -";
            nUdImdb.Value = 10;
            nUdSure.Value = 30;
            txtAciklama.Clear();
            txtYapimSirketi.Clear();
            txtBuyukResim.Clear();
            txtKucukResim.Clear();
            txtFilmAdi.Focus();
        }
    }
}
