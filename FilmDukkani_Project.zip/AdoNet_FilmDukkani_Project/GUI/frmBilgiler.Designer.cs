﻿namespace GUI
{
    partial class frmBilgiler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnFilmGuncelle = new System.Windows.Forms.Button();
            this.btnFilmEkle = new System.Windows.Forms.Button();
            this.btnKucukResim = new System.Windows.Forms.Button();
            this.btnBuyukResim = new System.Windows.Forms.Button();
            this.nUdSure = new System.Windows.Forms.NumericUpDown();
            this.nUdImdb = new System.Windows.Forms.NumericUpDown();
            this.cbYil = new System.Windows.Forms.ComboBox();
            this.txtAciklama = new System.Windows.Forms.TextBox();
            this.txtKucukResim = new System.Windows.Forms.TextBox();
            this.txtYapimSirketi = new System.Windows.Forms.TextBox();
            this.txtBuyukResim = new System.Windows.Forms.TextBox();
            this.txtFilmAdi = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFilmId = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nUdSure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUdImdb)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnFilmGuncelle);
            this.groupBox1.Controls.Add(this.btnFilmEkle);
            this.groupBox1.Controls.Add(this.btnKucukResim);
            this.groupBox1.Controls.Add(this.btnBuyukResim);
            this.groupBox1.Controls.Add(this.nUdSure);
            this.groupBox1.Controls.Add(this.nUdImdb);
            this.groupBox1.Controls.Add(this.cbYil);
            this.groupBox1.Controls.Add(this.txtAciklama);
            this.groupBox1.Controls.Add(this.txtKucukResim);
            this.groupBox1.Controls.Add(this.txtYapimSirketi);
            this.groupBox1.Controls.Add(this.txtBuyukResim);
            this.groupBox1.Controls.Add(this.txtFilmId);
            this.groupBox1.Controls.Add(this.txtFilmAdi);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(22, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(586, 486);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ekle / Güncelle ";
            // 
            // btnFilmGuncelle
            // 
            this.btnFilmGuncelle.Location = new System.Drawing.Point(192, 449);
            this.btnFilmGuncelle.Name = "btnFilmGuncelle";
            this.btnFilmGuncelle.Size = new System.Drawing.Size(342, 35);
            this.btnFilmGuncelle.TabIndex = 9;
            this.btnFilmGuncelle.Text = "Film Güncelle";
            this.btnFilmGuncelle.UseVisualStyleBackColor = true;
            this.btnFilmGuncelle.Visible = false;
            this.btnFilmGuncelle.Click += new System.EventHandler(this.btnFilmGuncelle_Click);
            // 
            // btnFilmEkle
            // 
            this.btnFilmEkle.Location = new System.Drawing.Point(192, 408);
            this.btnFilmEkle.Name = "btnFilmEkle";
            this.btnFilmEkle.Size = new System.Drawing.Size(340, 35);
            this.btnFilmEkle.TabIndex = 8;
            this.btnFilmEkle.Text = "Film Ekle";
            this.btnFilmEkle.UseVisualStyleBackColor = true;
            this.btnFilmEkle.Visible = false;
            this.btnFilmEkle.Click += new System.EventHandler(this.btnFilmEkle_Click);
            // 
            // btnKucukResim
            // 
            this.btnKucukResim.Location = new System.Drawing.Point(484, 356);
            this.btnKucukResim.Name = "btnKucukResim";
            this.btnKucukResim.Size = new System.Drawing.Size(48, 30);
            this.btnKucukResim.TabIndex = 4;
            this.btnKucukResim.Text = "---";
            this.btnKucukResim.UseVisualStyleBackColor = true;
            this.btnKucukResim.Click += new System.EventHandler(this.btnKucukResim_Click);
            // 
            // btnBuyukResim
            // 
            this.btnBuyukResim.Location = new System.Drawing.Point(484, 320);
            this.btnBuyukResim.Name = "btnBuyukResim";
            this.btnBuyukResim.Size = new System.Drawing.Size(48, 30);
            this.btnBuyukResim.TabIndex = 4;
            this.btnBuyukResim.Text = "---";
            this.btnBuyukResim.UseVisualStyleBackColor = true;
            this.btnBuyukResim.Click += new System.EventHandler(this.btnBuyukResim_Click);
            // 
            // nUdSure
            // 
            this.nUdSure.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nUdSure.Location = new System.Drawing.Point(382, 147);
            this.nUdSure.Maximum = new decimal(new int[] {
            240,
            0,
            0,
            0});
            this.nUdSure.Minimum = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.nUdSure.Name = "nUdSure";
            this.nUdSure.Size = new System.Drawing.Size(108, 30);
            this.nUdSure.TabIndex = 3;
            this.nUdSure.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // nUdImdb
            // 
            this.nUdImdb.DecimalPlaces = 1;
            this.nUdImdb.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nUdImdb.Location = new System.Drawing.Point(192, 147);
            this.nUdImdb.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nUdImdb.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nUdImdb.Name = "nUdImdb";
            this.nUdImdb.Size = new System.Drawing.Size(108, 30);
            this.nUdImdb.TabIndex = 2;
            this.nUdImdb.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // cbYil
            // 
            this.cbYil.FormattingEnabled = true;
            this.cbYil.Location = new System.Drawing.Point(192, 100);
            this.cbYil.Name = "cbYil";
            this.cbYil.Size = new System.Drawing.Size(340, 33);
            this.cbYil.TabIndex = 1;
            this.cbYil.Text = "- Yıl Seçiniz -";
            // 
            // txtAciklama
            // 
            this.txtAciklama.Location = new System.Drawing.Point(192, 183);
            this.txtAciklama.Multiline = true;
            this.txtAciklama.Name = "txtAciklama";
            this.txtAciklama.Size = new System.Drawing.Size(340, 81);
            this.txtAciklama.TabIndex = 4;
            // 
            // txtKucukResim
            // 
            this.txtKucukResim.Location = new System.Drawing.Point(192, 356);
            this.txtKucukResim.Name = "txtKucukResim";
            this.txtKucukResim.Size = new System.Drawing.Size(286, 30);
            this.txtKucukResim.TabIndex = 7;
            // 
            // txtYapimSirketi
            // 
            this.txtYapimSirketi.Location = new System.Drawing.Point(192, 270);
            this.txtYapimSirketi.Name = "txtYapimSirketi";
            this.txtYapimSirketi.Size = new System.Drawing.Size(340, 30);
            this.txtYapimSirketi.TabIndex = 5;
            // 
            // txtBuyukResim
            // 
            this.txtBuyukResim.Location = new System.Drawing.Point(192, 320);
            this.txtBuyukResim.Name = "txtBuyukResim";
            this.txtBuyukResim.Size = new System.Drawing.Size(286, 30);
            this.txtBuyukResim.TabIndex = 6;
            // 
            // txtFilmAdi
            // 
            this.txtFilmAdi.Location = new System.Drawing.Point(192, 56);
            this.txtFilmAdi.Name = "txtFilmAdi";
            this.txtFilmAdi.Size = new System.Drawing.Size(340, 30);
            this.txtFilmAdi.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 25);
            this.label5.TabIndex = 0;
            this.label5.Text = "Büyük Resim : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(496, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 25);
            this.label9.TabIndex = 0;
            this.label9.Text = "dk.";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(306, 152);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 25);
            this.label8.TabIndex = 0;
            this.label8.Text = "Süre : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 186);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 25);
            this.label4.TabIndex = 0;
            this.label4.Text = "Açıklaması : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 281);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(142, 25);
            this.label7.TabIndex = 0;
            this.label7.Text = "Yapım Şirketi : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 25);
            this.label3.TabIndex = 0;
            this.label3.Text = "IMDB Puanı : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 363);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(143, 25);
            this.label6.TabIndex = 0;
            this.label6.Text = "Küçük Resim : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Vizyon Yılı : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Film Adı : ";
            // 
            // txtFilmId
            // 
            this.txtFilmId.Location = new System.Drawing.Point(551, 20);
            this.txtFilmId.Name = "txtFilmId";
            this.txtFilmId.Size = new System.Drawing.Size(29, 30);
            this.txtFilmId.TabIndex = 0;
            this.txtFilmId.Visible = false;
            // 
            // frmBilgiler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(635, 510);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmBilgiler";
            this.Text = "frmBilgiler";
            this.Load += new System.EventHandler(this.frmBilgiler_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nUdSure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUdImdb)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnKucukResim;
        private System.Windows.Forms.Button btnBuyukResim;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.Button btnFilmGuncelle;
        public System.Windows.Forms.Button btnFilmEkle;
        public System.Windows.Forms.NumericUpDown nUdImdb;
        public System.Windows.Forms.ComboBox cbYil;
        public System.Windows.Forms.TextBox txtAciklama;
        public System.Windows.Forms.TextBox txtFilmAdi;
        public System.Windows.Forms.NumericUpDown nUdSure;
        public System.Windows.Forms.TextBox txtKucukResim;
        public System.Windows.Forms.TextBox txtYapimSirketi;
        public System.Windows.Forms.TextBox txtBuyukResim;
        public System.Windows.Forms.TextBox txtFilmId;
    }
}