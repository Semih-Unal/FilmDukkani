﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//---------------------------
using System.Data.SqlClient;
using System.Data;
//---------------------------
using Library._1_Model; // ekledik
using Library._2_Common; // Ekledik
using Library._3_DataAccessLayer;
using System.IO;

namespace GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Ör : 
            //Library._1_Model.Films yeniFilm = new Films();

            //yeniFilm.FilmAdi = "Propaganda";

            //-----

            // Ör : 
            this.Text = Library._2_Common.Tools.ProjectName.ToString();

            // Tools içinden iletişimimizi alalım
            Tools.GetConnectionString(Tools.ConnectionType.SQL); // Şifreli Bağlantı

            //Tools.GetConnectionString(Tools.ConnectionType.Windows); // Şifresiz Bağlantı

            //------------------------------------------
            VeriCek();
        }
        // Not : 
        // "lstwVeriler.Selectedİtem[0].SubItems[1].text" -> FilmId seçme
        private void VeriCek()
        {
            int i = 0;
            lstwVeriler.Items.Clear();
            imgImages.Images.Clear();

            List<Films> filmler = Filmler.List();

            foreach (Films film in filmler)
            {
                ListViewItem li = new ListViewItem();
                if (File.Exists(film.BuyukResim) == true)
                {
                    Image img = Image.FromFile(film.BuyukResim);
                    imgImages.Images.Add(img);
                    li.ImageIndex = i;
                    i++;
                }
                // li.Text = film.FilmId.ToString();
                li.SubItems.Add(film.FilmId.ToString());
                li.SubItems.Add(film.FilmAdi);
                li.SubItems.Add(film.Sene.ToString());
                li.SubItems.Add(film.Aciklama.ToString());
                li.SubItems.Add(film.BuyukResim);
                li.SubItems.Add(film.KucukResim);
                li.SubItems.Add(film.IMDBPuan.ToString());
                li.SubItems.Add(film.YapimSirketi);
                li.SubItems.Add(film.Sure.ToString());

                li.Tag = film;
                lstwVeriler.Items.Add(li);
            }

            toolStripStatusLabelVeriler.Text = lstwVeriler.Items.Count.ToString() + " Adet Veri Listelenmiştir...";
        }
        frmBilgiler frmYavru = new frmBilgiler();
        private void toolStripButtonYeniEkle_Click(object sender, EventArgs e)
        {
            frmYavru.btnFilmEkle.Visible = true;
            this.Hide();
            frmYavru.Show();
        }

        private void toolStripButtonGuncelle_Click(object sender, EventArgs e)
        {
            if (lstwVeriler.SelectedItems == null)
            {
                
                MessageBox.Show("Lütfen Güncellemek İstediğiniz Filmi Seçiniz!");
                return;
            }
            frmYavru.btnFilmGuncelle.Visible = true;
            frmYavru.txtFilmId.Text = lstwVeriler.SelectedItems[0].SubItems[1].Text;
            frmYavru.txtFilmAdi.Text = lstwVeriler.SelectedItems[0].SubItems[2].Text;
            frmYavru.cbYil.Text = lstwVeriler.SelectedItems[0].SubItems[3].Text;
            frmYavru.txtAciklama.Text = lstwVeriler.SelectedItems[0].SubItems[4].Text;
            frmYavru.txtBuyukResim.Text = lstwVeriler.SelectedItems[0].SubItems[5].Text;
            frmYavru.txtKucukResim.Text = lstwVeriler.SelectedItems[0].SubItems[6].Text;
            frmYavru.nUdImdb.Value = Convert.ToDecimal(lstwVeriler.SelectedItems[0].SubItems[7].Text);
            frmYavru.txtYapimSirketi.Text = lstwVeriler.SelectedItems[0].SubItems[8].Text;
            frmYavru.nUdSure.Value = Convert.ToDecimal(lstwVeriler.SelectedItems[0].SubItems[9].Text);
            this.Hide();
            frmYavru.Show();
        }

        private void toolStripButtonSil_Click(object sender, EventArgs e)
        {
            if (lstwVeriler.SelectedItems == null)
            {
                MessageBox.Show("Lütfen Silmek İstediğiniz Filmi Seçiniz!");
                return;
            }
            if (MessageBox.Show("Silmek İstediğinize Emin Misiniz?","- Silme İşlemi -", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                Filmler.DeleteItem(lstwVeriler.SelectedItems[0].SubItems[1].Text);
                VeriCek();
            }
        }

        private void toolStripButtonCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
